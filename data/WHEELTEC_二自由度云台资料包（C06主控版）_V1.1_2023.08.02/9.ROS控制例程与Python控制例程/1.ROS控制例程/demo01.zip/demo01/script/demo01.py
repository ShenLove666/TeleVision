#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from std_msgs.msg import String
import serial
import struct

if __name__ == '__main__':
    try:
        # 串口参数
        # 根据电脑的串口ID设置串口名称，COM为Windows上的串口号，Linux上可能是'/dev/ttyACM0'
        # 初始化串口
        port = "/dev/ttyACM0"  # 串口名称
        baudrate = 115200  # 波特率
        parity = 0

        # angle_bottom： 云台舵机 ； angle_top： 摆臂舵机
        # 在使用过程中只需修改这两个变量即可
        angle_bottom = 1
        angle_top = 1

        # 创建串口对象
        ser = serial.Serial(port, baudrate)

        angle = 1

        rospy.init_node('demo01', anonymous=True)
        rate = rospy.Rate(20) # 20hz
        
        while not rospy.is_shutdown():
            # angle_bottom： 云台舵机 ； angle_top： 摆臂舵机
            # 在使用过程中只需修改这两个变量即可
            # 循环将两个舵机从0到90度转动
            angle_bottom = angle
            angle_top = angle

            # BBC校验码
            parity = angle_bottom ^ parity
            parity = angle_top ^ parity

            # 用pack打包数据并发送
            pack = struct.pack("10B",0xff,0xfe,angle_bottom,angle_top,0x00,0x00,0x00,0x00,0x00,parity)


            # 发送数据
            ser.write(pack)

            angle += 1
            if angle>180:
                angle = 1

            rate.sleep()

    except rospy.ROSInterruptException:
        pass