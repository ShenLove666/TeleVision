#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import rclpy
from rclpy.node import Node
import serial
import struct

class SerialPublisher(Node):
    def __init__(self):
        super().__init__('demo01')
        # 串口参数
        port = "/dev/ttyACM0"  # 串口名称
        baudrate = 115200  # 波特率
        self.ser = serial.Serial(port, baudrate)
        self.angle = 1
        self.parity = 0

        # 20Hz循环频率
        self.timer = self.create_timer(0.05, self.timer_callback)

    def timer_callback(self):
        # angle_bottom： 云台舵机 ； angle_top： 摆臂舵机
        angle_bottom = self.angle
        angle_top = self.angle

        # BBC校验码
        self.parity = angle_bottom ^ self.parity
        self.parity = angle_top ^ self.parity

        # 用pack打包数据并发送
        pack = struct.pack("10B", 0xff, 0xfe, angle_bottom, angle_top, 0x00, 0x00, 0x00, 0x00, 0x00, self.parity)

        # 发送数据
        self.ser.write(pack)
        print("pan-tilt running...",self.angle)

        self.angle += 1
        if self.angle > 180:
            self.angle = 1

def main(args=None):
    rclpy.init(args=args)
    node = SerialPublisher()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()